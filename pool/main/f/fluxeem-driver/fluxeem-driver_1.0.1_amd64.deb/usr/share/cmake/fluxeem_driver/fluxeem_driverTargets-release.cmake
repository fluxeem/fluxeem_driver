#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "fluxeem::fluxeem_driver" for configuration "Release"
set_property(TARGET fluxeem::fluxeem_driver APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(fluxeem::fluxeem_driver PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libfluxeem_driver.so"
  IMPORTED_SONAME_RELEASE "libfluxeem_driver.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS fluxeem::fluxeem_driver )
list(APPEND _IMPORT_CHECK_FILES_FOR_fluxeem::fluxeem_driver "${_IMPORT_PREFIX}/lib/libfluxeem_driver.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
